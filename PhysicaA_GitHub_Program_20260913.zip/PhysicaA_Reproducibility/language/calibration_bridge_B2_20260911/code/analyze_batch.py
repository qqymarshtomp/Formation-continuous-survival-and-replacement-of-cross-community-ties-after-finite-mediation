import json
from datetime import datetime, timezone
from pathlib import Path
import shutil
import sys
import numpy as np

out = Path(__file__).resolve().parents[1]
manifest = json.loads((out / '执行前方案.json').read_text())
conditions = manifest['conditions']
ids = [r['id'] for r in conditions]
seeds = manifest['network_seeds']
off = manifest['config']['burnin'] + manifest['config']['intervention']
followup = manifest['config']['followup']
degree = np.empty((len(seeds), len(ids), off + followup + 1))
means = np.empty((len(seeds), len(ids)))
per_run = []
zero_checks = []
for si, seed in enumerate(seeds):
    for ci, condition in enumerate(conditions):
        with np.load(out / 'raw' / f'{seed}_{condition["id"]}.npz', allow_pickle=False) as saved:
            obs = saved['observations']
            logs = saved['logs']
            metrics = json.loads(str(saved['metrics']))
            log_metrics = json.loads(str(saved['log_metrics']))
        if condition['id'] == 'neutral_fixed_action':
            neutral_obs = obs.copy()
        if condition['frame_effect'] == 0:
            zero_checks.append(bool(np.array_equal(obs, neutral_obs, equal_nan=True)))
        b = obs[:, metrics.index('b')]
        degree[si, ci] = b
        means[si, ci] = np.trapezoid(b[off:], dx=1) / followup
        attempts = int(logs[:, log_metrics.index('mediation_attempts')].sum())
        row = {'seed': seed, 'condition': condition['id'], 'points': len(obs), 'ticks': len(logs), 'mean_postwithdrawal_degree': float(means[si,ci]), 'withdrawal_degree': float(b[off]), 'final_degree': float(b[-1]), 'mediation_attempts': attempts, 'max_count_residual': float(np.abs(logs[:,log_metrics.index('count_residual')]).max()), 'max_weight_residual': float(np.abs(logs[:,log_metrics.index('weight_residual')]).max()), 'no_mediation_after_withdrawal': bool(np.all(logs[off:,log_metrics.index('mediation_attempts')] == 0))}
        if condition['id'] == 'none':
            row.update(mean_frame_alignment=None, mean_action_alignment=None)
        else:
            row.update(mean_frame_alignment=float(logs[:,log_metrics.index('frame_alignment')].sum()/attempts), mean_action_alignment=float(logs[:,log_metrics.index('action_alignment')].sum()/attempts))
        per_run.append(row)

resamples = np.random.default_rng(manifest['uncertainty']['bootstrap_seed']).integers(0,len(seeds),size=(manifest['uncertainty']['bootstrap_samples'],len(seeds)))
cell_keys = list(dict.fromkeys((c['selection_rule'],c['mapping'],c['beta_id'],c['score_scope']) for c in conditions if c['kind'] == 'text'))
cell_means = {}
contrasts = []
cell_results = []
family_results = []
for key in cell_keys:
    rule, mapping, beta_id, scope = key
    for assignment in ['matched','shuffled']:
        indices = [ids.index(f'{rule}_{mapping}_{beta_id}_{family}_{scope}_{assignment}') for family in ['C1','C2']]
        cell_means[(*key,assignment)] = means[:,indices].mean(axis=1)
    diff = cell_means[(*key,'matched')] - cell_means[(*key,'shuffled')]
    interval = np.quantile(diff[resamples].mean(axis=1),[0.025,0.975])
    row = {'selection_rule':rule,'mapping':mapping,'beta_id':beta_id,'frame_effect':manifest['beta_cases'][beta_id],'score_scope':scope,'mean_effect':float(diff.mean()),'pointwise_95_interval':interval.tolist(),'positive_seeds':int((diff>0).sum()),'negative_seeds':int((diff<0).sum()),'zero_seeds':int((diff==0).sum()),'seed_effects':diff.tolist(),'seed_effect_sd':float(diff.std(ddof=1))}
    cell_results.append(row)
    for family in ['C1','C2']:
        values = means[:,ids.index(f'{rule}_{mapping}_{beta_id}_{family}_{scope}_matched')] - means[:,ids.index(f'{rule}_{mapping}_{beta_id}_{family}_{scope}_shuffled')]
        family_results.append({'selection_rule':rule,'mapping':mapping,'beta_id':beta_id,'score_scope':scope,'family':family,'mean_effect':float(values.mean()),'pointwise_95_interval':np.quantile(values[resamples].mean(axis=1),[.025,.975]).tolist(),'seed_effects':values.tolist()})
    if rule == 'fixed':
        for comparator in [f'original_{beta_id}','neutral_fixed_action','none']:
            contrasts.append(({'kind':'matched_minus_reference','selection_rule':rule,'mapping':mapping,'beta_id':beta_id,'score_scope':scope,'reference':comparator},cell_means[(*key,'matched')]-means[:,ids.index(comparator)]))

for mapping in ['square','sqrt','compressed']:
    for beta_id in ['weak','baseline','strong']:
        for scope in ['primary','secondary']:
            key = ('fixed',mapping,beta_id,scope)
            ref = ('fixed','identity',beta_id,scope)
            difference = (cell_means[(*key,'matched')]-cell_means[(*key,'shuffled')])-(cell_means[(*ref,'matched')]-cell_means[(*ref,'shuffled')])
            contrasts.append(({'kind':'mapping_change_in_effect','mapping':mapping,'beta_id':beta_id,'score_scope':scope,'reference':'identity'},difference))
    for scope in ['primary','secondary']:
        aware = ('aware',mapping,'baseline',scope)
        fixed = ('fixed',mapping,'baseline',scope)
        effect_difference = (cell_means[(*aware,'matched')]-cell_means[(*aware,'shuffled')])-(cell_means[(*fixed,'matched')]-cell_means[(*fixed,'shuffled')])
        contrasts.append(({'kind':'aware_minus_fixed_effect','mapping':mapping,'beta_id':'baseline','score_scope':scope},effect_difference))
        contrasts.append(({'kind':'aware_minus_fixed_matched_outcome','mapping':mapping,'beta_id':'baseline','score_scope':scope},cell_means[(*aware,'matched')]-cell_means[(*fixed,'matched')]))
contrast_results = []
for metadata, values in contrasts:
    contrast_results.append(metadata|{'mean':float(values.mean()),'pointwise_95_interval':np.quantile(values[resamples].mean(axis=1),[.025,.975]).tolist(),'positive_seeds':int((values>0).sum()),'negative_seeds':int((values<0).sum()),'seed_differences':values.tolist()})

condition_results=[]
for ci,condition in enumerate(conditions):
    values=means[:,ci]-means[:,ids.index('none')]
    rows=[r for r in per_run if r['condition']==condition['id']]
    row={'condition':condition,'mean_postwithdrawal_degree':float(means[:,ci].mean()),'mean_increment_vs_none':float(values.mean()),'increment_pointwise_95_interval':np.quantile(values[resamples].mean(axis=1),[.025,.975]).tolist(),'withdrawal_increment_vs_none':float((degree[:,ci,off]-degree[:,ids.index('none'),off]).mean()),'final_increment_vs_none':float((degree[:,ci,-1]-degree[:,ids.index('none'),-1]).mean())}
    if condition['id']=='none':
        row.update(mean_frame_alignment=None,mean_action_alignment=None)
    else:
        row.update(mean_frame_alignment=float(np.mean([r['mean_frame_alignment'] for r in rows])),mean_action_alignment=float(np.mean([r['mean_action_alignment'] for r in rows])))
    condition_results.append(row)
positive_grid=[r for r in cell_results if r['selection_rule']=='fixed' and r['frame_effect']>0]
negative=[r for r in cell_results if r['frame_effect']<0]
zero=[r for r in cell_results if r['frame_effect']==0]
summary={'stage':manifest['stage'],'finished_at_utc':datetime.now(timezone.utc).isoformat(),'planned_trajectories':manifest['trajectories_planned'],'completed_trajectories':len(per_run),'raw_files_count':len(list((out/'raw').glob('*.npz'))),'conditions_per_seed':len(ids),'numeric_seed_blocks':len(seeds),'network_seeds':seeds,'uncertainty':manifest['uncertainty'],'positive_grid_summary':{'cells':len(positive_grid),'positive_mean_cells':sum(r['mean_effect']>0 for r in positive_grid),'cells_with_positive_pointwise_lower_bound':sum(r['pointwise_95_interval'][0]>0 for r in positive_grid),'mean_effect_range':[min(r['mean_effect'] for r in positive_grid),max(r['mean_effect'] for r in positive_grid)],'not_a_simultaneous_bound_or_all_mapping_guarantee':True},'negative_control_cells':negative,'zero_control_cells':zero,'cell_effects':cell_results,'family_effects':family_results,'secondary_contrasts':contrast_results,'condition_results':condition_results,'checks':{'all_trajectories_complete':all(r['points']==501 and r['ticks']==500 for r in per_run),'all_mediated_conditions_600_attempts':all(r['mediation_attempts']==600 for r in per_run if r['condition']!='none'),'all_none_conditions_zero_attempts':all(r['mediation_attempts']==0 for r in per_run if r['condition']=='none'),'no_mediation_after_withdrawal':all(r['no_mediation_after_withdrawal'] for r in per_run),'all_paired_preintervention_degree_paths_equal':bool(np.all(degree[:,:,:51]==degree[:,:1,:51])),'zero_coefficient_trajectories_checked_against_neutral':len(zero_checks),'all_zero_coefficient_observation_paths_equal_neutral':all(zero_checks),'maximum_absolute_count_residual':max(r['max_count_residual'] for r in per_run),'maximum_absolute_weight_residual':max(r['max_weight_residual'] for r in per_run)},'environment':{'python':sys.version,'numpy':np.__version__},'new_gpu_calls':0,'new_human_ratings':0,'reserved_12_run':False,'formal_240_released':False,'older_data_overwritten':False}
(out/'逐轨迹指标.json').write_text(json.dumps(per_run,ensure_ascii=False,indent=2)+'\n')
(out/'结果汇总.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
np.savez_compressed(out/'汇总轨迹.npz',cross_degree=degree,postwithdrawal_means=means,seeds=np.asarray(seeds),condition_ids=np.asarray(ids),bootstrap_indices=resamples)
print(json.dumps({'completed':len(per_run),'checks':summary['checks'],'positive_grid':summary['positive_grid_summary'],'cells':[{k:r[k] for k in ['selection_rule','mapping','beta_id','score_scope','mean_effect','pointwise_95_interval','positive_seeds','negative_seeds','zero_seeds']} for r in cell_results]},ensure_ascii=False,indent=2))
