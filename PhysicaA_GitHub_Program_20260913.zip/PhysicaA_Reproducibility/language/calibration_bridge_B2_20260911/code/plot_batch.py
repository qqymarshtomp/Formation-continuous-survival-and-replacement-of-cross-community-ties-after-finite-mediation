import json
from pathlib import Path
import shutil
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

out = Path(__file__).resolve().parents[1]
summary = json.loads((out/'结果汇总.json').read_text())
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none'})
styles = [('identity','Identity','#1768ac','o'),('square','Square','#bc6c25','s'),('sqrt','Square root','#25866b','^'),('compressed','Central compression','#8b5ca6','D')]
fig,axes=plt.subplots(1,2,figsize=(12,4.7),sharey=True,layout='constrained')
for ax,scope,title in zip(axes,['primary','secondary'],['A. Message score','B. Message + card score']):
    for mapping,label,color,marker in styles:
        rows=sorted([r for r in summary['cell_effects'] if r['selection_rule']=='fixed' and r['mapping']==mapping and r['score_scope']==scope],key=lambda r:r['frame_effect'])
        x=np.array([r['frame_effect'] for r in rows])
        y=np.array([r['mean_effect'] for r in rows])
        lo=np.array([r['pointwise_95_interval'][0] for r in rows])
        hi=np.array([r['pointwise_95_interval'][1] for r in rows])
        ax.errorbar(x,y,yerr=[y-lo,hi-y],color=color,marker=marker,label=label,linewidth=1.4,markersize=5,capsize=3)
    ax.axhline(0,color='#71717a',linewidth=.8)
    ax.axvline(0,color='#a1a1aa',linewidth=.7,linestyle=':')
    ax.set(title=title,xlabel=r'Framing response coefficient $\beta_q$',xticks=[-1.25,0,.5,1.25,2.5])
    ax.legend(frameon=False,fontsize=8,loc='upper left')
axes[0].set_ylabel('Matched minus shuffled\n(mean degree over 400 withdrawal ticks)')
fig.suptitle('B2: mapping sensitivity with the original text-selection rule fixed',fontsize=12)
fig.savefig(out/'B2映射与响应强度.png',dpi=180)
fig.savefig(out/'B2映射与响应强度.svg')
plt.close(fig)

fig,axes=plt.subplots(1,2,figsize=(12,4.6),layout='constrained')
for ax,kind,title,ylabel in zip(axes,['aware_minus_fixed_matched_outcome','aware_minus_fixed_effect'],['A. Change in matched outcome','B. Change in matched-minus-shuffled effect'],['Mapping-aware minus fixed selection\n(mean postwithdrawal degree)','Mapping-aware minus fixed selection\n(change in paired effect)']):
    for offset,scope,label,color,marker in [(-.1,'primary','Message','#1768ac','o'),(.1,'secondary','Message + card','#b45372','s')]:
        rows=[next(r for r in summary['secondary_contrasts'] if r['kind']==kind and r['mapping']==mapping and r['score_scope']==scope) for mapping in ['square','sqrt','compressed']]
        y=np.array([r['mean'] for r in rows])
        lo=np.array([r['pointwise_95_interval'][0] for r in rows])
        hi=np.array([r['pointwise_95_interval'][1] for r in rows])
        ax.errorbar(np.arange(3)+offset,y,yerr=[y-lo,hi-y],fmt=marker,color=color,capsize=4,label=label,markersize=6)
    ax.axhline(0,color='#71717a',linewidth=.8)
    ax.set(title=title,ylabel=ylabel,xticks=[0,1,2],xticklabels=['Square','Square root','Central\ncompression'],xlim=(-.5,2.5))
    ax.legend(frameon=False,fontsize=9)
fig.suptitle(r'B2: effect of knowing the mapping, $\beta_q=1.25$',fontsize=12)
fig.savefig(out/'B2固定选择与重选对照.png',dpi=180)
fig.savefig(out/'B2固定选择与重选对照.svg')
plt.close(fig)
print('Two figures saved as PNG and SVG.')
