from copy import deepcopy
from dataclasses import replace
import json
from pathlib import Path
import sys
import numpy as np

out = Path(__file__).resolve().parents[1]
(out / 'execution').mkdir(exist_ok=True)
sys.path.insert(0, str(out / 'code'))
import model
import model_b1

human = (0.15463917525773196, 0.5, 0.85)
old_cfg = model_b1.Config(n=100, mediation_intensity=0.1, frame_values=human)
cfg = model.Config(**old_cfg.to_dict(), selection_values=human)
for new_policy, old_policy in [('text_fixed_matched', 'text_matched'), ('text_fixed_shuffled', 'text_shuffled'), ('text_matched', 'text_matched'), ('text_shuffled', 'text_shuffled'), ('fixed_action', 'fixed_action'), ('none', 'none')]:
    new = model.NetworkModel(cfg, 110101)
    old = model_b1.NetworkModel(old_cfg, 110101)
    for tick in range(40):
        new_log = new.step(new_policy)
        old_log = old.step(old_policy)
        np.testing.assert_array_equal(new.w, old.w)
        np.testing.assert_array_equal(new.r, old.r)
        np.testing.assert_array_equal(new.x, old.x)
        assert new_log == old_log
        assert new.rng_nat.bit_generator.state == old.rng_nat.bit_generator.state
        assert new.rng_med.bit_generator.state == old.rng_med.bit_generator.state

nonlinear = replace(cfg, frame_values=tuple(s ** 0.5 for s in human))
choice_differences = []
for policy in ['text_fixed_matched', 'text_fixed_shuffled', 'text_matched', 'text_shuffled']:
    state = model.NetworkModel(nonlinear, 110102)
    rng = deepcopy(state.rng_med)
    m = round(nonlinear.mediation_intensity * nonlinear.n / 2)
    priority = 0.10 + (1 - state.w[state.cx]) * (1 - 0.5 * state.r[state.cx])
    keys = -np.log(rng.random(len(state.cx))) / priority
    idx = state.cx[np.argpartition(keys, m - 1)[:m]]
    rng.normal(0, nonlinear.policy_noise, m)
    rng.normal(0, nonlinear.policy_noise, m)
    permutation = rng.permutation(m)
    fixed_choice = np.abs(state.context[idx, None] - np.asarray(human)).argmin(axis=1)
    aware_choice = np.abs(state.context[idx, None] - np.asarray(nonlinear.frame_values)).argmin(axis=1)
    choice = fixed_choice if policy.startswith('text_fixed') else aware_choice
    frame = np.asarray(nonlinear.frame_values)[choice]
    if policy.endswith('shuffled'):
        frame = frame[permutation]
    expected_alignment = np.sum(1 - 2 * np.abs(frame - state.context[idx]))
    log = state.step(policy, natural_contact=False)
    np.testing.assert_allclose(log['frame_alignment'], expected_alignment, rtol=0, atol=1e-14)
    choice_differences.append(int((fixed_choice != aware_choice).sum()))
assert min(choice_differences) > 0

zero_cfg = replace(nonlinear, frame_effect=0)
states = [model.NetworkModel(zero_cfg, 110103) for _ in range(5)]
policies = ['text_fixed_matched', 'text_fixed_shuffled', 'text_matched', 'text_shuffled', 'neutral_fixed_action']
for tick in range(60):
    for state, policy in zip(states, policies):
        state.step(policy)
    for state in states[1:]:
        np.testing.assert_array_equal(state.w, states[0].w)
        np.testing.assert_array_equal(state.r, states[0].r)
        np.testing.assert_array_equal(state.x, states[0].x)
        assert state.rng_nat.bit_generator.state == states[0].rng_nat.bit_generator.state
        assert state.rng_med.bit_generator.state == states[0].rng_med.bit_generator.state

record = {'B1_policies_and_identity_fixed_selection_match_B1_over_40_ticks': True, 'nonlinear_fixed_and_aware_selection_alignments_match_independent_one_step_calculation': True, 'one_step_choices_that_differ_between_rules': choice_differences, 'all_five_policies_coincide_at_zero_frame_coefficient_over_60_ticks': True, 'random_streams_preserved': True, 'test_seeds': [110101,110102,110103], 'tests_excluded_from_research_trajectory_count': True}
(out / 'execution/new_policy_verification.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
