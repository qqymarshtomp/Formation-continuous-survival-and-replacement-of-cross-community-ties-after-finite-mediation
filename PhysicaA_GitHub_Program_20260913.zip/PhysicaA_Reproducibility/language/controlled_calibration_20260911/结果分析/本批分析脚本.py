import json
from collections import Counter
from datetime import datetime, timezone
from fractions import Fraction
from pathlib import Path
import re
import shutil

stage = Path(__file__).resolve().parents[1]
research = stage / '研究者材料_勿发给评阅者'
out = stage / '结果分析'
raw = out / '原始提交'
raw.mkdir(parents=True, exist_ok=True)
protocol = json.loads((research / '执行前方案.json').read_text())
messages = json.loads((research / '冻结文本_6条.json').read_text())
prior_confirmation = json.loads((out / '填写来源记录.json').read_text())['prior_confirmation']
analyzed_at = datetime.now(timezone.utc).isoformat()
labels = ['R', 'P', 'M', 'U']
values = {'R': Fraction(0), 'P': Fraction(1), 'M': Fraction(1, 2)}
ratings = []
input_checks = []

# The supplied original human forms are the external inputs to this reanalysis.
for who in ['A', 'B']:
    source = raw / f'校准盲评表_{who}_6条_已填写.md'
    archived = raw / source.name
    submitted = archived.read_text()
    mapping = json.loads((research / f'研究者映射_{who}.json').read_text())
    mapped = {row['review_sentence_id']: row for row in mapping}
    headings = re.findall(r'^###\s+(\S+)[ \t]*$', submitted, re.MULTILINE)
    duplicates = [sid for sid, n in Counter(headings).items() if n > 1]
    missing = sorted(set(mapped) - set(headings))
    extra = sorted(set(headings) - set(mapped))
    if duplicates or missing or extra:
        raise ValueError(f'{who}: duplicate IDs {duplicates}; missing IDs {missing}; unexpected IDs {extra}')
    blocks = re.findall(r'^### ([AB]\d{2}\.\d{2})[ \t]*\n(.*?)(?=^##(?:#)? |^---[ \t]*$|\Z)', submitted, re.MULTILINE | re.DOTALL)
    if len(blocks) != len(mapping):
        raise ValueError(f'{who}: {len(blocks)} readable response blocks for {len(mapping)} expected items')
    for sid, body in blocks:
        response = re.fullmatch(r'\s*(.*?)\n\n选择：[ \t]*([RPMU])[ \t]+理由或疑问：[ \t]*(.*?)\s*', body, re.DOTALL)
        if response is None:
            raise ValueError(f'{sid}: a single R/P/M/U label and the original response format are required')
        sentence, label, reason = response.groups()
        if sentence != mapped[sid]['sentence']:
            raise ValueError(f'{sid}: submitted sentence differs from the frozen original')
        if label == 'U' and reason.strip() in ['', '____']:
            raise ValueError(f'{sid}: U requires the reviewer\'s reason')
        row = dict(mapped[sid])
        row.update(reviewer=who, label=label, reason=reason, archived_source=archived.name)
        ratings.append(row)
    input_checks.append({
        'reviewer': who, 'source': str(source), 'archived_source': str(archived),
        'items': len(blocks), 'missing_ids': missing, 'duplicate_ids': duplicates,
        'unexpected_ids': extra, 'all_original_sentences_unchanged': True,
        'all_labels_valid_and_filled': True, 'all_U_have_reasons': True,
        'order_matches_blank_form': headings == [row['review_sentence_id'] for row in mapping],
        'byte_copy_matches_submission': archived.read_bytes() == source.read_bytes(),
    })

joined_lookup = {}
for row in ratings:
    if row['item_kind'] == 'message':
        source_id = row['candidate_id']
    else:
        source_id = row['source_id']
    key = (row['item_kind'], source_id, row['sentence_index'])
    if row['reviewer'] == 'A':
        joined_lookup[key] = {
            'item_kind': row['item_kind'], 'source_id': source_id,
            'sentence_index': row['sentence_index'], 'sentence': row['sentence'], 'words': row['words'],
        }
    joined_lookup[key][row['reviewer']] = {
        'review_sentence_id': row['review_sentence_id'], 'label': row['label'], 'reason': row['reason'],
    }
joined = list(joined_lookup.values())
for row in joined:
    row['agreement'] = row['A']['label'] == row['B']['label']
message_items = [row for row in joined if row['item_kind'] == 'message']
card_items = [row for row in joined if row['item_kind'] == 'common_action_card']
disagreements = [row for row in joined if not row['agreement']]
uncertain = [row for row in ratings if row['label'] == 'U']
counts = {who: {label: sum(row[who]['label'] == label for row in message_items) for label in labels} for who in ['A', 'B']}
matrix = [[sum(row['A']['label'] == a and row['B']['label'] == b for row in message_items) for b in labels] for a in labels]
agreement_count = sum(row['agreement'] for row in message_items)
observed = Fraction(agreement_count, len(message_items))
chance = sum(Fraction(counts['A'][label] * counts['B'][label], len(message_items) ** 2) for label in labels)
kappa = (observed - chance) / (1 - chance)

# The submitted batch contains no U; numeric values below come only from its actual human labels.
card_metrics = {}
for who in ['A', 'B']:
    rows = [row for row in ratings if row['reviewer'] == who and row['item_kind'] == 'common_action_card']
    words = sum(row['words'] for row in rows)
    numerator = sum(row['words'] * values[row['label']] for row in rows)
    card_metrics[who] = {'words': words, 'weighted_numerator': float(numerator), 'score': float(numerator / words), 'label_counts': dict(Counter(row['label'] for row in rows))}

scores = []
exact_scores = {}
for message in messages:
    cid = message['candidate_id']
    family, level = cid.split('_h')
    row = {'candidate_id': cid, 'wording_family': family, 'intended_mix': float(level), 'source_origin': message['author']}
    for who in ['A', 'B']:
        items = [r for r in ratings if r['reviewer'] == who and r['item_kind'] == 'message' and r['candidate_id'] == cid]
        words = sum(r['words'] for r in items)
        numerator = sum(r['words'] * values[r['label']] for r in items)
        primary = numerator / words
        secondary = (numerator + Fraction(card_metrics[who]['weighted_numerator'])) / (words + card_metrics[who]['words'])
        row[who] = {
            'message_words': words, 'sentence_items': len(items),
            'label_counts': {label: sum(r['label'] == label for r in items) for label in labels},
            'words_by_label': {label: sum(r['words'] for r in items if r['label'] == label) for label in labels},
            'weighted_numerator': float(numerator),
            'primary_score': float(primary), 'primary_exact_fraction': str(primary),
            'secondary_score': float(secondary), 'secondary_exact_fraction': str(secondary),
        }
        exact_scores[(who, family, float(level), 'primary')] = primary
        exact_scores[(who, family, float(level), 'secondary')] = secondary
    scores.append(row)

metrics = {}
for who in ['A', 'B']:
    metrics[who] = {}
    for score_kind in ['primary', 'secondary']:
        family_results = []
        deltas = []
        for family in protocol['wording_families']:
            ordered = [exact_scores[(who, family, h, score_kind)] for h in protocol['intended_mix_levels']]
            delta = ordered[2] - ordered[0]
            deltas.append(delta)
            family_results.append({
                'wording_family': family, 'scores_in_target_order': [float(v) for v in ordered],
                'high_minus_low': float(delta), 'high_minus_low_exact_fraction': str(delta),
                'positive_endpoint_difference': delta > 0,
                'nondecreasing_triplet': ordered[0] <= ordered[1] <= ordered[2],
                'strictly_increasing_triplet': ordered[0] < ordered[1] < ordered[2],
            })
        mean_delta = sum(deltas) / len(protocol['wording_families'])
        metrics[who][score_kind] = {
            'families': family_results,
            'mean_endpoint_difference': float(mean_delta),
            'mean_endpoint_difference_exact_fraction': str(mean_delta),
            'positive_endpoint_pairs': sum(r['positive_endpoint_difference'] for r in family_results),
            'nondecreasing_triplets': sum(r['nondecreasing_triplet'] for r in family_results),
            'mean_score_by_target': {str(h): float(sum(exact_scores[(who, family, h, score_kind)] for family in protocol['wording_families']) / 2) for h in protocol['intended_mix_levels']},
        }

repeated_texts = []
for sentence, count in Counter(row['sentence'] for row in message_items).items():
    if count > 1:
        occurrences = [row for row in message_items if row['sentence'] == sentence]
        repeated_texts.append({
            'sentence': sentence, 'occurrences': occurrences,
            'within_reviewer_label_variation': {who: len({row[who]['label'] for row in occurrences}) > 1 for who in ['A', 'B']},
        })

provenance = {
    'analysis_at_utc': analyzed_at, 'stage': protocol['stage'],
    'workflow': 'Independent human blind-review workflow previously confirmed by the user; these two returned forms are recorded under that workflow.',
    'prior_confirmation': prior_confirmation,
    'current_round_confirmation': 'Files returned by the user; no new identity or independence verification was claimed.',
    'reviewers': ['A', 'B'], 'rating_records': len(ratings),
    'message_contextual_items': len(message_items), 'shared_card_items': len(card_items),
    'text_authorship': 'All six texts assistant-authored, not AutoDL model-run outputs.',
    'original_forms_preserved': True, 'original_A_B_labels_preserved_separately': True,
    'assistant_labels_or_adjudication_added': False, 'new_gpu_calls': 0,
}
summary = {
    'stage': protocol['stage'], 'analysis_at_utc': analyzed_at,
    'protocol_frozen_at_utc': protocol['frozen_at_utc'],
    'status': 'returned_forms_analyzed', 'input_checks': input_checks,
    'rating_records_received': len(ratings), 'message_rating_records': len(message_items) * 2,
    'card_rating_records': len(card_items) * 2,
    'message_items': len(message_items), 'distinct_message_sentence_texts': len({row['sentence'] for row in message_items}),
    'message_label_counts': counts, 'confusion_label_order': labels, 'A_rows_B_columns': matrix,
    'message_agreements': agreement_count, 'message_agreement_rate': float(observed),
    'cohen_kappa_unweighted_descriptive': float(kappa), 'chance_agreement_from_marginals': float(chance),
    'card_agreements': sum(row['agreement'] for row in card_items), 'card_metrics': card_metrics,
    'disagreement_items': len(disagreements), 'U_rating_records': len(uncertain),
    'nonempty_reason_records': sum(bool(row['reason']) for row in ratings),
    'repeated_message_texts': len(repeated_texts),
    'repeated_texts_with_within_reviewer_label_variation': {who: sum(row['within_reviewer_label_variation'][who] for row in repeated_texts) for who in ['A', 'B']},
    'raters': metrics,
    'primary_score_definition': protocol['primary_score'], 'secondary_score_definition': protocol['secondary_score'],
    'no_U_in_this_batch': True, 'consensus_labels_created': False,
    'interpretation': 'Descriptive separation of six controlled assistant-authored texts; no independent gold accuracy, M discrimination, model reliability, network generalization or behavioral outcome inference.',
    'binary_gate': None, 'original_automatic_coder_gate_passed': False,
    'reserved_12_run': False, 'formal_240_released': False, 'new_gpu_calls': 0,
}
for filename, data in [
    ('输入核对记录.json', input_checks), ('填写来源记录.json', provenance),
    ('原始逐项评分_88条.json', ratings), ('两位评分对应_44项.json', joined),
    ('消息分数_6条.json', scores), ('分歧记录.json', disagreements),
    ('不确定项记录.json', uncertain), ('重复句上下文记录.json', repeated_texts),
    ('统计汇总.json', summary),
]:
    (out / filename).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(summary, ensure_ascii=False, indent=2))
