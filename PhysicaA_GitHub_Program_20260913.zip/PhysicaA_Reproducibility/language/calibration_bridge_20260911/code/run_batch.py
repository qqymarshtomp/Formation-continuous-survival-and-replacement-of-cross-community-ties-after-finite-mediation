import json
from datetime import datetime, timezone
from pathlib import Path
import sys
import time

import numpy as np

out = Path(__file__).resolve().parents[1]
(out / 'execution').mkdir(exist_ok=True)
(out / 'raw').mkdir(exist_ok=True)
sys.path.insert(0, str(out / 'code'))
from model import Config, NetworkModel

part = int(sys.argv[1])
manifest = json.loads((out / '执行前方案.json').read_text())
metrics = ['tick', 'b', 'strength', 'coverage', 'cross_fraction', 'degree', 'trust', 'opinion_gap', 'natural_acceptance', 'survival']
log_metrics = ['natural_births', 'mediation_births', 'deletions', 'natural_weight', 'mediation_weight', 'decay_weight', 'mediation_attempts', 'mediation_successes', 'frame_alignment', 'action_alignment', 'natural_attempts', 'natural_successes', 'count_residual', 'weight_residual']
started = time.perf_counter()
completed = []
for seed in manifest['network_seeds'][part::4]:
    for condition in manifest['conditions']:
        config = dict(manifest['config'])
        config['frame_values'] = tuple(condition['frame_values'])
        cfg = Config(**config)
        model = NetworkModel(cfg, seed)
        rows = [[model.observe()[k] for k in metrics]]
        logs = []
        for tick in range(cfg.burnin + cfg.intervention + cfg.followup):
            policy = condition['policy'] if cfg.burnin <= tick < cfg.off else 'none'
            log = model.step(policy)
            if model.tick == cfg.off:
                model.mark_withdrawal()
            observation = model.observe()
            rows.append([observation[k] for k in metrics])
            logs.append([log[k] for k in log_metrics])
        record = {'stage': manifest['stage'], 'seed': seed, 'condition': condition, 'config': cfg.to_dict(), 'completed_at_utc': datetime.now(timezone.utc).isoformat()}
        path = out / 'raw' / f'{seed}_{condition["id"]}.npz'
        np.savez_compressed(path, observations=np.asarray(rows), logs=np.asarray(logs), metrics=json.dumps(metrics), log_metrics=json.dumps(log_metrics), metadata=json.dumps(record))
        completed.append(path.name)
        print(f'part {part}: {len(completed)}/36 completed; seed {seed}, {condition["id"]}; {time.perf_counter()-started:.1f} s', flush=True)
(out / 'execution' / f'part{part}_completion.json').write_text(json.dumps({'part': part, 'completed_files': completed, 'count': len(completed), 'elapsed_seconds': time.perf_counter()-started, 'finished_at_utc': datetime.now(timezone.utc).isoformat()}, indent=2) + '\n')
