import json
from datetime import datetime, timezone
from pathlib import Path
import shutil
import sys

import numpy as np
import scipy
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

out = Path(__file__).resolve().parents[1]
manifest = json.loads((out / '执行前方案.json').read_text())
seeds = manifest['network_seeds']
conditions = manifest['conditions']
ids = [r['id'] for r in conditions]
off = manifest['config']['burnin'] + manifest['config']['intervention']
followup = manifest['config']['followup']
per_run = []
degree = np.empty((len(seeds), len(ids), off + followup + 1))
post_mean = np.empty((len(seeds), len(ids)))
for si, seed in enumerate(seeds):
    for ci, condition in enumerate(conditions):
        with np.load(out / 'raw' / f'{seed}_{condition["id"]}.npz', allow_pickle=False) as saved:
            observations = saved['observations']
            logs = saved['logs']
            metrics = json.loads(str(saved['metrics']))
            log_metrics = json.loads(str(saved['log_metrics']))
        b = observations[:, metrics.index('b')]
        degree[si, ci] = b
        post_mean[si, ci] = np.trapezoid(b[off:], dx=1) / followup
        attempts = int(logs[:, log_metrics.index('mediation_attempts')].sum())
        row = {
            'seed': seed, 'condition': condition['id'],
            'trajectory_points': len(observations), 'event_log_ticks': len(logs),
            'withdrawal_degree': float(b[off]), 'final_degree': float(b[-1]),
            'mean_postwithdrawal_degree': float(post_mean[si, ci]),
            'mediation_attempts': attempts,
            'max_absolute_count_residual': float(np.max(np.abs(logs[:, log_metrics.index('count_residual')]))),
            'max_absolute_weight_residual': float(np.max(np.abs(logs[:, log_metrics.index('weight_residual')]))),
            'no_mediation_after_withdrawal': bool(np.all(logs[off:, log_metrics.index('mediation_attempts')] == 0)),
        }
        if condition['id'] == 'none':
            row.update(mean_frame_alignment=None, mean_action_alignment=None, mediated_success_fraction=None)
        else:
            row.update(
                mean_frame_alignment=float(logs[:, log_metrics.index('frame_alignment')].sum() / attempts),
                mean_action_alignment=float(logs[:, log_metrics.index('action_alignment')].sum() / attempts),
                mediated_success_fraction=float(logs[:, log_metrics.index('mediation_successes')].sum() / attempts),
            )
        per_run.append(row)

bootstrap = np.random.default_rng(manifest['uncertainty']['bootstrap_seed']).integers(0, len(seeds), size=(manifest['uncertainty']['bootstrap_samples'], len(seeds)))
condition_results = []
for ci, condition in enumerate(conditions):
    increments = post_mean[:, ci] - post_mean[:, ids.index('none')]
    interval = np.quantile(increments[bootstrap].mean(axis=1), [0.025, 0.975])
    run_rows = [r for r in per_run if r['condition'] == condition['id']]
    item = {
        'condition': condition['id'],
        'mean_postwithdrawal_degree': float(post_mean[:, ci].mean()),
        'mean_increment_vs_none': float(increments.mean()),
        'increment_vs_none_pointwise_95_interval': interval.tolist(),
        'withdrawal_degree_mean': float(degree[:, ci, off].mean()),
        'withdrawal_increment_vs_none': float((degree[:, ci, off] - degree[:, ids.index('none'), off]).mean()),
        'final_degree_mean': float(degree[:, ci, -1].mean()),
        'final_increment_vs_none': float((degree[:, ci, -1] - degree[:, ids.index('none'), -1]).mean()),
    }
    if condition['id'] == 'none':
        item.update(mean_frame_alignment=None, mean_action_alignment=None)
    else:
        item.update(mean_frame_alignment=float(np.mean([r['mean_frame_alignment'] for r in run_rows])), mean_action_alignment=float(np.mean([r['mean_action_alignment'] for r in run_rows])))
    condition_results.append(item)

aggregate_curves = {}
aggregate_metrics = {}
contrasts = {}
for scope in ['primary', 'secondary']:
    for assignment in ['matched', 'shuffled']:
        indices = [ids.index(f'{family}_{scope}_{assignment}') for family in ['C1', 'C2']]
        aggregate_curves[f'{scope}_{assignment}'] = degree[:, indices].mean(axis=1)
        aggregate_metrics[f'{scope}_{assignment}'] = post_mean[:, indices].mean(axis=1)
    contrasts[f'{scope}_family_mean_matched_minus_shuffled'] = aggregate_metrics[f'{scope}_matched'] - aggregate_metrics[f'{scope}_shuffled']
    for family in ['C1', 'C2']:
        contrasts[f'{family}_{scope}_matched_minus_shuffled'] = post_mean[:, ids.index(f'{family}_{scope}_matched')] - post_mean[:, ids.index(f'{family}_{scope}_shuffled')]
    for comparator in ['original_fixed_action', 'nominal_grid', 'neutral_fixed_action', 'none']:
        contrasts[f'{scope}_family_mean_matched_minus_{comparator}'] = aggregate_metrics[f'{scope}_matched'] - post_mean[:, ids.index(comparator)]
contrasts['secondary_minus_primary_family_mean_matched'] = aggregate_metrics['secondary_matched'] - aggregate_metrics['primary_matched']
contrast_results = []
for name, values in contrasts.items():
    interval = np.quantile(values[bootstrap].mean(axis=1), [0.025, 0.975])
    contrast_results.append({
        'contrast': name, 'seed_values': [{'seed': seed, 'value': float(v)} for seed, v in zip(seeds, values)],
        'mean': float(values.mean()), 'sample_sd': float(values.std(ddof=1)),
        'min_seed_value': float(values.min()), 'max_seed_value': float(values.max()),
        'positive_seed_values': int((values > 0).sum()), 'zero_seed_values': int((values == 0).sum()),
        'pointwise_95_percentile_interval': interval.tolist(),
    })
primary = next(r for r in contrast_results if r['contrast'] == 'primary_family_mean_matched_minus_shuffled')
secondary = next(r for r in contrast_results if r['contrast'] == 'secondary_family_mean_matched_minus_shuffled')

summary = {
    'stage': manifest['stage'], 'finished_at_utc': datetime.now(timezone.utc).isoformat(),
    'planned_trajectories': manifest['trajectories_planned'], 'completed_trajectories': len(per_run),
    'raw_files_count': len(list((out / 'raw').glob('*.npz'))),
    'independent_numeric_seed_blocks': len(seeds), 'conditions_per_seed': len(conditions),
    'text_families': 2, 'new_human_ratings': 0, 'new_gpu_calls': 0,
    'nominal_intensity': manifest['config']['mediation_intensity'],
    'realized_mediated_participations_per_node_per_tick': 2 * round(manifest['config']['mediation_intensity'] * manifest['config']['n'] / 2) / manifest['config']['n'],
    'primary_result': primary, 'secondary_scoring_scope_result': secondary,
    'condition_results': condition_results, 'contrasts': contrast_results,
    'uncertainty': manifest['uncertainty'],
    'checks': {
        'all_trajectories_501_points': all(r['trajectory_points'] == 501 for r in per_run),
        'all_event_logs_500_ticks': all(r['event_log_ticks'] == 500 for r in per_run),
        'all_mediated_conditions_600_attempts': all(r['mediation_attempts'] == 600 for r in per_run if r['condition'] != 'none'),
        'all_none_conditions_zero_mediated_attempts': all(r['mediation_attempts'] == 0 for r in per_run if r['condition'] == 'none'),
        'all_conditions_share_preintervention_degree_paths_per_seed': bool(np.all(degree[:, :, :51] == degree[:, :1, :51])),
        'no_mediation_after_withdrawal': all(r['no_mediation_after_withdrawal'] for r in per_run),
        'maximum_absolute_count_residual': max(r['max_absolute_count_residual'] for r in per_run),
        'maximum_absolute_weight_residual': max(r['max_absolute_weight_residual'] for r in per_run),
    },
    'environment': {'python': sys.version, 'numpy': np.__version__, 'scipy': scipy.__version__, 'matplotlib': matplotlib.__version__},
    'original_data_overwritten': False, 'reserved_12_run': False, 'formal_240_released': False,
}
(out / '逐轨迹指标.json').write_text(json.dumps(per_run, ensure_ascii=False, indent=2) + '\n')
(out / '结果汇总.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
np.savez_compressed(out / '汇总轨迹.npz', cross_degree=degree, postwithdrawal_means=post_mean, seeds=np.asarray(seeds), condition_ids=np.asarray(ids), bootstrap_indices=bootstrap)

plt.rcParams.update({'font.size': 10, 'axes.spines.top': False, 'axes.spines.right': False, 'svg.fonttype': 'none'})
fig, axes = plt.subplots(1, 2, figsize=(12, 4.6), gridspec_kw={'width_ratios': [1.5, 1]}, layout='constrained')
baseline = degree[:, ids.index('none'), off:]
series = [
    ('Original continuous', degree[:, ids.index('original_fixed_action')], '#52525b', '-'),
    ('Nominal grid', degree[:, ids.index('nominal_grid')], '#a16207', '-'),
    ('Message / matched', aggregate_curves['primary_matched'], '#1768ac', '-'),
    ('Message / shuffled', aggregate_curves['primary_shuffled'], '#1768ac', '--'),
    ('Message + card / matched', aggregate_curves['secondary_matched'], '#b45372', '-'),
    ('Message + card / shuffled', aggregate_curves['secondary_shuffled'], '#b45372', '--'),
]
for label, trajectory, color, style in series:
    axes[0].plot(np.arange(followup + 1), (trajectory[:, off:] - baseline).mean(axis=0), label=label, color=color, linestyle=style, linewidth=1.5)
axes[0].axhline(0, color='#a1a1aa', linewidth=0.8)
axes[0].set(xlabel='Ticks since withdrawal', ylabel='Mean cross-community degree increment\n(relative to no mediation)', title='A. Conditional network trajectories')
axes[0].legend(fontsize=8, frameon=False, ncol=2, loc='upper right')
for pos, (result, color) in enumerate([(primary, '#1768ac'), (secondary, '#b45372')]):
    values = np.array([r['value'] for r in result['seed_values']])
    axes[1].scatter(pos + np.linspace(-0.09, 0.09, len(values)), values, color=color, alpha=0.45, s=22)
    lower, upper = result['pointwise_95_percentile_interval']
    axes[1].errorbar(pos, result['mean'], yerr=[[result['mean'] - lower], [upper - result['mean']]], color=color, marker='D', capsize=6, markersize=7, linewidth=2)
axes[1].axhline(0, color='#71717a', linewidth=0.8)
axes[1].set(xticks=[0, 1], xticklabels=['Message', 'Message + card'], xlim=(-0.5, 1.5), ylabel='Matched minus shuffled\n(mean degree over 400 withdrawal ticks)', title='B. Paired effects by numerical seed')
fig.suptitle('B1: identity-mapping sensitivity, fixed action = 0.5', fontsize=12)
fig.savefig(out / 'B1映射敏感性.png', dpi=180)
fig.savefig(out / 'B1映射敏感性.svg')
plt.close(fig)
print(json.dumps({'completed': len(per_run), 'checks': summary['checks'], 'primary': primary, 'secondary': secondary, 'contrasts_compact': [{k:r[k] for k in ['contrast','mean','pointwise_95_percentile_interval']} for r in contrast_results]}, ensure_ascii=False, indent=2))
