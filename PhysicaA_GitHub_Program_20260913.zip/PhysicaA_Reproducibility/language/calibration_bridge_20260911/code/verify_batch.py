import json
from dataclasses import replace
from pathlib import Path
import sys
import numpy as np

out = Path(__file__).resolve().parents[1]
(out / 'execution').mkdir(exist_ok=True)
sys.path.insert(0, str(out / 'code'))
import model
import model_original

cfg = model.Config(n=100, mediation_intensity=0.10)
original_config = cfg.to_dict()
del original_config['frame_values']
for policy in ['none', 'fixed_action']:
    changed = model.NetworkModel(cfg, 110001)
    original = model_original.NetworkModel(model_original.Config(**original_config), 110001)
    for tick in range(60):
        new_log = changed.step(policy)
        old_log = original.step(policy)
        np.testing.assert_array_equal(changed.w, original.w)
        np.testing.assert_array_equal(changed.r, original.r)
        np.testing.assert_array_equal(changed.x, original.x)
        assert new_log == old_log
        assert changed.rng_nat.bit_generator.state == original.rng_nat.bit_generator.state
        assert changed.rng_med.bit_generator.state == original.rng_med.bit_generator.state

cfg = replace(cfg, frame_effect=0, frame_values=(0.15463917525773196, 0.5, 0.85))
matched = model.NetworkModel(cfg, 110002)
shuffled = model.NetworkModel(cfg, 110002)
neutral = model.NetworkModel(cfg, 110002)
for tick in range(60):
    logs = [matched.step('text_matched'), shuffled.step('text_shuffled'), neutral.step('neutral_fixed_action')]
    for candidate in [shuffled, neutral]:
        np.testing.assert_array_equal(candidate.w, matched.w)
        np.testing.assert_array_equal(candidate.r, matched.r)
        np.testing.assert_array_equal(candidate.x, matched.x)
        assert candidate.rng_nat.bit_generator.state == matched.rng_nat.bit_generator.state
        assert candidate.rng_med.bit_generator.state == matched.rng_med.bit_generator.state
    assert all(r['count_residual'] == 0 for r in logs)
    assert max(abs(r['weight_residual']) for r in logs) < 1e-10

cfg = replace(cfg, frame_effect=1.25)
state = model.NetworkModel(cfg, 110003)
for tick in range(10):
    state.step('text_shuffled')
state.save(out / 'execution/test_checkpoint.npz')
restored = model.NetworkModel.load(out / 'execution/test_checkpoint.npz')
for tick in range(20):
    state.step('text_matched')
    restored.step('text_matched')
    np.testing.assert_array_equal(state.w, restored.w)
    np.testing.assert_array_equal(state.r, restored.r)
    np.testing.assert_array_equal(state.x, restored.x)

record = {'original_none_and_fixed_action_match_unmodified_model_for_60_ticks': True, 'new_matched_shuffled_neutral_coincide_when_frame_effect_zero_for_60_ticks': True, 'natural_and_mediation_random_streams_match': True, 'new_policy_checkpoint_restores_exact_future': True, 'count_and_weight_conservation_in_zero_effect_test': True, 'test_seeds': [110001, 110002, 110003], 'test_runs_are_not_research_trajectories': True}
(out / 'execution/new_policy_verification.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
